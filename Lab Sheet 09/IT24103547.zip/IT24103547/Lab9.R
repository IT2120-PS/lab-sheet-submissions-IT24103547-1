setwd("C:\\Users\\User\\OneDrive\\Desktop\\IT24103547")
## Exercise Q1
# Part i:
baking_times <- rnorm(25, mean = 45, sd = 2)

# Part ii: 
test_result <- t.test(baking_times, mu = 46, alternative = "less")

# Print the test results
test_result
